/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a;
    printf("Enter a number:");
    scanf("%d",&a);
    if(a%3==0 && a%5==0)
    {
        printf("Good Number");
    }
    else if(a%3==0)
    {
        printf("Bad Number");
    }
    else if(a%5==0)
    {
        printf("Poor Number");
    }
    else
    {
        printf("-1");
    }
    return 0;
}
